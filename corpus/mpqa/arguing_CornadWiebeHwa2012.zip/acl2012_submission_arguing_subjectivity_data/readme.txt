
This archive contains the dataset accompanying the submission to ACL 2012 entitled "Recognizing Arguing and Argument Tags". 

Our annotated dataset is stored in the training/ subdirectory as a set of .xml datafiles. These datafiles can be opened as "GATE Document"s in the GATE 6.1 GUI or newer (http://gate.ac.uk/).

Our stance structure is stored as a mindmap in the file "healthcare_argstruct_3_clean_condensed.mm". This mindmap can be viewed using FreeMind 0.9.0 or newer (http://freemind.sourceforge.net/wiki/index.php/Main_Page). An exported HTML version of the stance structure is also provided.
